import React from 'react';


const userInput = () => {
	return <p><input type="text" name="number"/></p>
};

export default userInput;
