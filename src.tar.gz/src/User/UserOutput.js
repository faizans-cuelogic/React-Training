import React from 'react';

const userOutput = () => {
	return <p> Im Output</p>
};

export default userOutput;
